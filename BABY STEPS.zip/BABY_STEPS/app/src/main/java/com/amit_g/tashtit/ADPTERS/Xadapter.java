package com.amit_g.tashtit.ADPTERS;

public class Xadapter {
}
