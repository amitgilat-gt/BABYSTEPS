package com.amit_g.viewmodel;

import android.app.Application;

import com.amit_g.repository.BASE.BaseRepository;
import com.amit_g.viewmodel.BASE.BaseViewModel;

public class XviewModel extends BaseViewModel {
    @Override
    protected BaseRepository createRepository(Application application) {
        return null;
    }

    public XviewModel(Class tEntity, Class tCollection, Application application) {
        super(tEntity, tCollection, application);
    }
}
