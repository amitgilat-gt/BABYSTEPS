package com.amit_g.model;

public class Vaccine {
    private String name;
    private double dueToAge;

    public Vaccine() {
    }

    public Vaccine(String name, double dueToAge) {
        this.name = name;
        this.dueToAge = dueToAge;
    }

}
