package com.amit_g.model;

import com.amit_g.model.BASE.BaseList;

public class AllProgress extends BaseList<Progress,AllProgress> {
}
