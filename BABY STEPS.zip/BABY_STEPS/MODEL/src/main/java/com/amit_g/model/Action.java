package com.amit_g.model;

public enum Action {
    DIAPER_CHANGE,
    Vaccine
}
