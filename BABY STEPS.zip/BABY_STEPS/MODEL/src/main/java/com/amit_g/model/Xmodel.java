package com.amit_g.model;

import com.amit_g.model.BASE.BaseEntity;

public class Xmodel extends BaseEntity {
}
