package com.amit_g.model;

public enum Gender {
    MALE ,
    FEMALE
}

