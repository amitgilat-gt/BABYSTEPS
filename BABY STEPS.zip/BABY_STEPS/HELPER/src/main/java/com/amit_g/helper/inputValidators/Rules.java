package com.amit_g.helper.inputValidators;

import java.util.ArrayList;

public class Rules extends ArrayList<Rule> {
}
