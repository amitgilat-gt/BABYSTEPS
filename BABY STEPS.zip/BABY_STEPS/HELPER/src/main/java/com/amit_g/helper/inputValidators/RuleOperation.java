package com.amit_g.helper.inputValidators;

public enum RuleOperation {
    REQUIRED,
    TEXT,
    HEBREW_TEXT,
    NAME,
    NUMBER,
    DATE,
    PASSWORD,
    COMPARE
}
