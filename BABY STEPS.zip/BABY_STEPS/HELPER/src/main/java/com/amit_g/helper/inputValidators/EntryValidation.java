package com.amit_g.helper.inputValidators;

public interface EntryValidation {
    void    setValidation();
    boolean validate();
}
