package com.amit_g.helper.inputValidators;

public enum ComapreOperation {
    EQUALS,
    NOT_EQUALS,
    LESS_THEN,
    LESS_THEN_OR_EQUALS,
    GREATER_THEN,
    GEARTER_THEN_OR_EQUALS
}
